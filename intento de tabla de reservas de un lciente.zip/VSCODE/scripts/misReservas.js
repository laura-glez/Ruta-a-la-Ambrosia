
// async function obtenerReservas(idUsuario) {
//     try {
//       const res = await fetch(`http://localhost:9003/reserva/usuarioId/${idUsuario}`);
//       const reservas = await res.json();
      
//       if (!reservas || reservas.length === 0) {
//         document.getElementById('tabla').innerHTML = `<p>No se encontraron reservas</p>`;
//         return;
//       }
//       misreservas = reservas;
//       console.log(misreservas);
//       renderizarTablaReservas();
//     } catch (error) {
//       console.error('Error al obtener reservas:', error);
//       document.getElementById('tabla').innerHTML = `<p style="color:red">${error.message}</p>`;
//     }
// }

// function renderizarTablaReservas() {
//     const tablaContainer = document.getElementById('tabla');
 
//     const filas = reservas.map((e, index) => `
//       <tr>
//         <td class="idR">${e.idReserva || "N/A"}</td>
//         <td class="idE>${e.idEvento || "Sin evento"}</td>
//         <td class="nombreE">${e.nombreEvento || "Sin evento"}</td>
//         <td class="precioE">${e.precioVenta ?? "No especificado"}</td>
//         <td class="precio">${e.precioEvento ?? "No especificado"}</td>
//         <td class="cantidad">
//             <input type="number" value="${e.cantidad ?? 1}" class="cantidad" data-idReserva="${reserva.idReserva}" min="1" max="10" />
//         </td>
//         <td>
//             <button class="guardarCantidadBtn" data-idReserva="${e.idReserva}">Guardar</button>
//         </td>
//         <td>
//             <button class="eliminarReservaBtn" data-idReserva="${e.idReserva}">Cancelar Reserva</button>
//         </td>
//       </tr>
//     `).join('');


//     tablaContainer.innerHTML = `
//       <br><br>
//       <table id="tablaReservas" border="1" cellspacing="0" cellpadding="5" style="border-collapse: collapse; width: 100%;">
//         <thead>
//           <tr>
//             <th>ID Reserva</th>
//             <th>Evento ID</th>
//             <th>Nombre Evento</th>
//             <th>Precio Evento</th>
//             <th>Precio Venta</th>
//             <th>Cantidad</th>
//             <th>Modificar</th>
//             <th>Cancela tu Reserva</th>
//           </tr>
//         </thead>
//         <tbody>
//           ${filas}
//         </tbody>
//       </table>
//     `;


//     const guardarBtns = document.querySelectorAll('.guardarCantidadBtn');
//     guardarBtns.forEach(btn => {
//         btn.addEventListener("click", function () {
//             const idReserva = this.getAttribute('data-idReserva');
//             const cantidadInput = this.closest('tr').querySelector('.cantidad');
//             const nuevaCantidad = cantidadInput.value;
//             guardarCantidadModificada(idReserva, nuevaCantidad); 
//         });
//     });

  
//     const eliminarBtns = document.querySelectorAll('.eliminarReservaBtn');
//     eliminarBtns.forEach(btn => {
//         btn.addEventListener("click", function () {
//             const idReserva = this.getAttribute('data-idReserva');
//             eliminarReserva(idReserva);  
//         });
//     });
// }
// async function getUsuario(idUsuario) {
//     try {
//         const res = await fetch(`http://localhost:9003/usuario/buscarDatosUsuario/${idUsuario}`);
//         if (!res.ok) {
//             throw new Error(`Error al obtener el usuario: ${res.statusText}`);
//         }
//         const user = await res.json();
//         return user;
//     } catch (error) {
//         document.getElementById('tabla').innerHTML = `<p style="color:red">${error.message}</p>`;
//         throw error; 
//     }
//   }

// async function guardarCantidadModificada() {
//     let eventos = [];
//     const reservaModificada = { 
//          idReserva: document.querySelector('.idR').value, 
//          cantidad: document.querySelector('.cantidad').value,
//          precio: document.querySelector('.precio').value,
//          precioEvento: document.querySelector('.precioE').value,
//          evento: {idEvento: document.querySelector('.idE').idEvento},
//          usuario:{idUsuario: idUsuario} 
//     };
//     console.log(reservaModificada);
//     try {
//         const response = await fetch('http://localhost:9003/reserva/modificar', {
//             method: 'PUT',
//             headers: {
//                 'Content-Type': 'application/json',
//             },
//             body: JSON.stringify(reservaModificada),
//         });

//         if (response.ok) {
//             alert("Reserva modificada con éxito");
//             obtenerReservas(idUsuario); 
//         } else {
//             throw new Error('Error al modificar la reserva');
//         }
//     } catch (error) {
//         console.error('Error al modificar la reserva:', error);
//         alert('Hubo un problema al modificar la reserva.');
//     }
// console.log(reservaModificada);
// }



// async function eliminarReserva(idReserva) {
//     const confirmDelete = confirm("¿Estás seguro de eliminar esta reserva?");
    
//     if (confirmDelete) {
//         try {
            
//             const response = await fetch(`http://localhost:9003/reserva/eliminar/${idReserva}`, {
//                 method: 'DELETE',
//             });

//             if (response.ok) {
//                 alert("Reserva cancelada con éxito");
//                 obtenerReservas(idUsuario); 
//             } else {
//                 throw new Error('No se pudo cancelar la reserva');
//             }
//         } catch (error) {
//             console.error('Error al cancelar la reserva:', error);
//             alert('Hubo un problema al cancelar la reserva.');
//         }
//     }
// }


const idUsuario = JSON.parse(localStorage.getItem('usuario')).idUsuario;
obtenerReservas(idUsuario);

// Función para cerrar sesión
const cerrarSesion = document.getElementById('cerrarSesion');
cerrarSesion.addEventListener('click', function(e) {
    e.preventDefault();
    localStorage.clear();
    window.location.href = "prueba.html";
});


      // Función para realizar la solicitud con fetch
      async function obtenerReservas() {
        try {
            const response = await fetch(`http://localhost:9003/reserva/usuarioId/${idUsuario}`);  // URL de tu API
            if (!response.ok) {
                throw new Error('Error al obtener los datos');
            }
            const data = await response.json();
            pintarTabla(data);  // Llamamos a pintar la tabla con los datos obtenidos
        } catch (error) {
            //console.error('Error en la solicitud:', error);
        }
    }

    // Referencia al cuerpo de la tabla
    const tbody = document.querySelector('#tabla tbody');

    // Función para crear una fila con los datos
    function crearFila(reserva) {
        const tr = document.createElement('tr');

        reserva.forEach(dato => {
            const td = document.createElement('td');
            td.textContent = dato;
            tr.appendChild(td);
        });

        // Crear botones de "Modificar" y "Eliminar"
        const tdModificar = document.createElement('td');
        const btnModificar = document.createElement('button');
        btnModificar.textContent = 'Modificar';
        btnModificar.classList.add('modificar');
        btnModificar.addEventListener('click', () => modificarFila(reserva[0]));  // El primer valor es el ID
        tdModificar.appendChild(btnModificar);
        tr.appendChild(tdModificar);

        const tdEliminar = document.createElement('td');
        const btnEliminar = document.createElement('button');
        btnEliminar.textContent = 'Eliminar';
        btnEliminar.classList.add('eliminar');
        btnEliminar.addEventListener('click', () => eliminarFila(tr));  // Eliminar la fila
        tdEliminar.appendChild(btnEliminar);
        tr.appendChild(tdEliminar);

        return tr;
    }

    // Función para pintar la tabla
    function pintarTabla(reservas) {
        tbody.innerHTML = '';  // Limpiar tabla
        reservas.forEach(reserva => {
            const tr = crearFila(reserva);
            tbody.appendChild(tr);
        });
    }

    // Función para modificar una fila (solo ejemplo, puedes hacer algo más complejo)
    function modificarFila(idReserva) {
        alert(`Modificando la reserva con ID: ${idReserva}`);
        // Aquí puedes agregar lógica para modificar la reserva (como abrir un formulario, etc.)
    }

    // Función para eliminar una fila
    function eliminarFila(fila) {
        const respuesta = confirm('¿Estás seguro de que deseas eliminar esta reserva?');
        if (respuesta) {
            fila.remove();  // Eliminar la fila
        }
    }

    // Llamar a la función para obtener los datos y pintar la tabla
    obtenerReservas();